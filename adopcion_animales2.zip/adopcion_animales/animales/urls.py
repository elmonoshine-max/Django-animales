from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import AdopcionViewSet

router = DefaultRouter()
router.register(r'adopciones', AdopcionViewSet)

urlpatterns = [
    path('', include(router.urls)),
]