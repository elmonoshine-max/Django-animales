from django.contrib import admin
from .models import Adopcion

admin.site.register(Adopcion)