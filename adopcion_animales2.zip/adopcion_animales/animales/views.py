from rest_framework import viewsets
from .models import Adopcion
from .serializers import AdopcionSerializer

class AdopcionViewSet(viewsets.ModelViewSet):
    queryset = Adopcion.objects.all()
    serializer_class = AdopcionSerializer