from django.db import models

class Adopcion(models.Model):
    nombre_mascota = models.CharField(max_length=100)
    especie = models.CharField(max_length=50)
    edad = models.IntegerField()
    adoptante = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre_mascota